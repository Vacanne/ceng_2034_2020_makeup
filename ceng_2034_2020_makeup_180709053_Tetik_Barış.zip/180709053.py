#Barış Tetik
import os
from enum import unique
import psutil
import requests
import uuid
from multiprocessing import Pool
import hashlib
import time
import threading
def process(urls):
 try:
 pid = os.fork()
 except OSError:
 exit("Could not create a child process")
 if pid > 0: # It blocks orphan process, so we do not need to remove any file.
 os.waitpid(pid, 0)
 # Multiprocessing part
 cpu_count = os.cpu_count()
 files = os.listdir()
 print(files)
 files.remove("main.py")
 #files.remove("venv") #pycharm oldugu icin var, silinebilir
 #files.remove(".idea")# pycharm oldugu icin var, silinebilir
 with Pool(len(files)) as p:
 md5_files = (p.map(md5_converter, files))
 print(md5_files)
 else:
 print("Child pid is = {}\n".format(os.getpid()))
 #Threading part
 threads = []
 for url in urls:
 new_thread = threading.Thread(target=download_file, args=(url,))
 threads.append(new_thread)
 new_thread.start()
 for old_thread in threads:
 old_thread.join()
def download_file(url, file_name=None):
 r = requests.get(url, allow_redirects=True)
 file = file_name if file_name else str(uuid.uuid4())
 open(file, 'wb').write(r.content)
def md5_converter(filename):
    hash_md5 = hashlib.md5()
    with open(filename, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()
urls = ["http://wiki.netseclab.mu.edu.tr/images/thumb/f/f7/MSKU-BlockchainResearchGroup.jpeg/300px-MSKU-BlockchainResearchGroup.jpeg",
"https://upload.wikimedia.org/wikipedia/tr/9/98/Mu%C4%9Fla_S%C4%B1tk%C4%B1_Ko%C3%A7man_%C3%9Cniversitesi_logo.png",
"https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Hawai%27i.jpg/1024px-Hawai%27i.jpg",
"http://wiki.netseclab.mu.edu.tr/images/thumb/f/f7/MSKU-BlockchainResearchGroup.jpeg/300px-MSKU-BlockchainResearchGroup.jpeg",
"https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Hawai%27i.jpg/1024px-Hawai%27i.jpg"]
before=time.time() #timer to kill slow processes starts here
process(urls)
after = time.time()
time= after - before
if time < 30:
 print("it's below 30 seconds")
else:
 os.kill(pid, signal.SIGSTOP)
 print("it was over 30 seconds")
print(psutil.virtual_memory()) # memory datas